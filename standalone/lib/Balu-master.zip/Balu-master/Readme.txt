Balu Toolbox Matlab version 4.0
Domingo Mery
e-mail: dmery@ing.puc.cl
http://dmery.ing.puc.cl
Departamento de Ciencia de la Computacion
Pontificia Universidad Catolica de Chile
(c) 2008-2014

Installation:

Once you have downloaded and unziped the distribution zip file:

- Start Matlab
- Change into the folder you unziped the files
- Execute setup.m

That's all! Balu doesn't need any compilation. The installation just add the Balu directories to search path of Matlab. 

NOTE: Certain functions of Balu call functions from the following toolboxes: VLFeat, Image Processing, Neural Network and Bioinformatics. If you want to use these Balu functions you must install the mentioned toolboxes (see details in command list).


-------------------------------------------------------

Balu  :  Kid, I only got so much room up in this noggin...
         and it's fillin' up fast!
Mowgli:  You just don't understand.
Balu  :  All right. How's about layin' it out for me.

-------------------------------------------------------
Please visit Balu's webpage:

http://dmery.ing.puc.cl/index.php/balu/
--------------------------------------------------------

I'd like to hear about any bugs that you find, or suggestions for 
improvements.
