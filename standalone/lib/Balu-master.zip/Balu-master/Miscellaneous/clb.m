delete(Bio_statusbar)
close all