function ix = indices(i,m)
ix = ((i-1)*m+1:i*m)';