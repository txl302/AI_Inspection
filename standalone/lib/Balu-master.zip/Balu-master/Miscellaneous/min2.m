function s = min2(x)
s = min(x(:));