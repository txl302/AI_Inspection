function s = sum2(x)
s = sum(x(:));