function s = mean2(x)
s = mean(x(:));