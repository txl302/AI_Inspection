function imshows(I)
imshow(I,[])