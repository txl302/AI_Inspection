function plotc(varargin)
clb
plot(varargin{:})