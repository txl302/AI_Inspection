% Balu Help for Feature Transformation
%
%    see also Bft_norm              
%             Bft_pca               
%             Bft_plsr              


