% Balu Help for Clustering
%
%    see also Bct_kmeans            
%             Bct_meanshift         
%             Bct_medoidshift       
