% Balu Help for Performance Evaluation
%
%    see also Bev_confusion         
%             Bev_performance       
%             Bev_holdout           
%             Bev_jackknife         
%             Bev_bootstrap         
%             Bev_bootstrap0632     
%             Bev_crossval          
%             Bev_confidence        
%             Bev_roc               


