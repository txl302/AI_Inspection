% Balu Help for Input/Output
%
%    see also Bio_segshow           
%             Bio_edgeview          
%             Bio_plotfeatures      
%             Bio_printfeatures     
%             Bio_loadimg           
%             Bio_latextable
%             Bio_sendmail
%             Bio_labelregion
%             Bio_labelimages
%             Bio_drawellipse




