% Balu Help for Feature Analysis
%
%    see also Bfa_jfisher           
%             Bfa_sp100             
%             Bfa_score             
%             Bfa_bestcorr          
%             Bfa_bestcorrn         
%             Bfa_corrsearch        
%             Bfa_dXi2              
%             Bfa_vecsimilarity     
